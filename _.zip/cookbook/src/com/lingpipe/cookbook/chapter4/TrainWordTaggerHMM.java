package com.lingpipe.cookbook.chapter4;

public class TrainWordTaggerHMM {

	
	//read tweets
}
